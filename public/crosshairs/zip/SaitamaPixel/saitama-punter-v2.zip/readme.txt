﻿=== Saitama Punter v2 Cursor Set ===

By: 000 (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/saitama-punter-v2

Author's description:

 Saitama Punter, from "One Punch Man" 

Pixel Version, 2021

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.