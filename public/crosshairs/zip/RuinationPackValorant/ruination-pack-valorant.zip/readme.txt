﻿=== Ruination Pack - Valorant Cursor Set ===

By: ATT (http://www.rw-designer.com/user/95357) xtttst@gmail.com

Download: http://www.rw-designer.com/cursor-set/ruination-pack-valorant

Author's description:

This pack contains all 17 cursors that were made in the theme of Ruination from the big event that is going on in the games made by Riot Games.

All the cursors except for the Normal Select are animated (on loop). A lot of glowing ones this time!

(I fixed the Vertical Select)
Please join the Realworld Design Discord server! https://discord.gg/gYExDtKctA

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.