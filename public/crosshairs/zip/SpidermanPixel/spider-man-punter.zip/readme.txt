﻿=== Spider-Man Cursor Set ===

By: 000 (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/spider-man-punter

Author's description:

 "Spider-Man Cursor, from Marvel vs Capcom"

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.