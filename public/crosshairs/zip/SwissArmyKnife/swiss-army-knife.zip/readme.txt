﻿=== Swiss Army Knife Cursor Set ===

By: MintPepper (http://www.rw-designer.com/user/61590)

Download: http://www.rw-designer.com/cursor-set/swiss-army-knife

Author's description:

This is Swiss Army Knife!
Do whatever you want with this cursor!

*This Swiss army knife looks a bit ridiculous...*

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.