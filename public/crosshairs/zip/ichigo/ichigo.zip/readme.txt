﻿=== Ichigo Cursor Set ===

By: 000 (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/ichigo

Author's description:

 Ichigo Cursors, Sprites From "Sprites Resource"

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.