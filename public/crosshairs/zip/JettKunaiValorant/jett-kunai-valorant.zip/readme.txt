﻿=== Jett Kunai - Valorant Cursor Set ===

By: ATT (http://www.rw-designer.com/user/95357) xtttst@gmail.com

Download: http://www.rw-designer.com/cursor-set/jett-kunai-valorant

Author's description:

This pack has all 17 cursor roles based on Jett's Kunai from Valorant. This is the first cursor pack I made partly with Blender, though I did not make the Kunai model.

All of these are either animated or glowing (and I added the Suppressed animation from KAY/O for Unavailable cuz why not)

Join the RealWorld Discord server! https://discord.gg/pCUjpRBmhY

Model Source:
This work is based on "Valorant Jett's Knife"
(https://sketchfab.com/3d-models/valorant-jetts-knife-e3f27f6752eb48a6b5da286020624d68) by Examensstudent1003 (https://sketchfab.com/amundh) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)



==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.