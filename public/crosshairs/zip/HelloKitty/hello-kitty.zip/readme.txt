﻿=== Hello Kitty Cursor Set ===

By: 15pets+ (http://www.rw-designer.com/user/48261) busyluvitall@gmail.com

Download: http://www.rw-designer.com/cursor-set/hello-kitty

Author's description:

Never-before-seen Hello Kitty cursor set. First ever made on this site, original! I am an absolute Hello Kitty fan so I found this extremely important. It has every version of cursor used in Windows 7. Compatible with Windows 7. If compatible with others, description will be updated.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.