﻿=== Default Dancing Cursor Set ===

By: ᴋɪᴛᴛᴇɴꜱ (http://www.rw-designer.com/user/85593) owotangerineowo@gmail.com

Download: http://www.rw-designer.com/cursor-set/default-dancing

Author's description:

Varied Fortnite Default dancing contains
one Dark Gray / grey (my favorite-)
one Black 
Three different rainbow types (first [fast] is my favorite)

Comment which rainbow is your favorite out of the three i'm curious lmao

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.