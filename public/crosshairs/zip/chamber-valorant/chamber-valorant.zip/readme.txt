﻿=== Chamber - Valorant Cursor Set ===

By: ATT (http://www.rw-designer.com/user/95357) xtttst@gmail.com

Download: http://www.rw-designer.com/cursor-set/chamber-valorant

Author's description:

It's been a while..
This pack contains all 17 cursors based on the agent Chamber from Valorant. If you do not know who that is, I recommend watching this: https://www.youtube.com/watch?v=FUoqAn5T4h4

All but two of the cursors are animated (the normal select is, as usual, not animated so that the rest of the cursors work as made).
The cursors may not look animated in the preview, but will once they have been applied.
Join the RealWorld Design Discord server! https://discord.gg/mQCKymnYxY

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.