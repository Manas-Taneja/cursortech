﻿=== Yoru - Valorant Cursor Set ===

By: ATT (http://www.rw-designer.com/user/95357) xtttst@gmail.com

Download: http://www.rw-designer.com/cursor-set/yoru-valorant

Author's description:

This pack has all 17 cursor roles based on the agent Yoru from Valorant. This is probably my favourite set so far (probably biased cuz it's for my favourite agent).
If you don't know who Yoru is, watch this https://youtu.be/hhlgphVf-1g

Almost all cursor roles are animated.

Join the RealWorld Discord server! https://discord.gg/pCUjpRBmhY

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.