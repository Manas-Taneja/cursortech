﻿=== Soyjak/Wojak Cursor Set ===

By: the_real_yakub

Download: http://www.rw-designer.com/cursor-set/soyjak-wojak

Author's description:

Assorted soyjak/wojak cursors. The original pointer IS NOT MINE, will credit when I find the creator.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.