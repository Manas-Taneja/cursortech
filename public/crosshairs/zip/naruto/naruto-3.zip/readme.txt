﻿=== Naruto Cursor Set ===

By: 000 (http://www.rw-designer.com/user/96786)

Download: http://www.rw-designer.com/cursor-set/naruto-3

Author's description:

 Naruto Cursors Sprites from "Sprites Resource"

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.